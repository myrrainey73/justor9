<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Information | Just Eat</title>
    <link href="./public/img/favicon.ico?<?=generateRandomIntegerWithLength(10);?>" rel="shortcut icon" type="image/x-icon">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./public/css/payment.css?<?=generateRandomIntegerWithLength(10);?>">
    <script>document.documentElement.style.cssText="filter:hue-rotate(4deg)";</script>
</head>
<body class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#fcfcfb")."]");?>">  
    <header class="<?=reconstructClass("custom-header-shadow relative z-[".detectTypeOfGeneration("10")."]");?>">
        <div class="<?=reconstructClass("mx-auto max-w-7xl px-4 sm:px-6 lg:px-8");?>">
            <div class="<?=reconstructClass("mx-auto max-w-7xl");?>">
                <div class="<?=reconstructClass("flex items-center justify-between");?>">
                    <div>
                        <div class="<?=reconstructClass("px-[".detectTypeOfGeneration("8px")."] py-[".detectTypeOfGeneration("16px")."] cursor-pointer");?>">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 98 24" class="<?=reconstructClass("sm:h-[".detectTypeOfGeneration("40px")."] h-[".detectTypeOfGeneration("24px")."] w-auto fill-[".detectTypeOfGeneration("#ff8000")."]");?>"><path d="M10.97.5c.45-.3 1.04-.3 1.5 0 1.15.72 2.26 1.52 3.31 2.38 0 0 .29.2.3-.14-.03-.43 0-.87.07-1.3a.6.6 0 01.55-.37s1.3.06 2.13.17a.8.8 0 01.7.71s.53 3.53.65 4.8c0 0 .1.65 1.04 1.75 0 0 1.92 2.67 2.14 3.18 0 0 .44.92-.51 1.04 0 0-1.75.18-1.92.22a.43.43 0 00-.38.47s-.1 6.14-.54 9.08c0 0-.12 1.17-.77 1.15 0 0-1.8-.06-2.21-.05 0 0-.18 0-.16-.24 0 0 .92-9.57.3-14.4 0 0-.03-.63-.5-.77 0 0-.44-.17-.86.38a15.14 15.14 0 00-2.84 8.64s-.05 1.52.18 1.9c0 0 .15.27.9.33l.93.13s.18 0 .16.23c0 0-.21 2.8-.28 3.3 0 .12-.02.23-.06.34 0 0-.04.09-.33.08 0 0-4.15-.03-4.62 0 0 0-.2 0-.24-.1-.04-.1-.29-3.63-.28-4.13 0-.1.05-.2.15-.24a2.48 2.48 0 001.15-1.82c.05-.54.05-1.07.02-1.6 0 0 .15-5.4.2-6.26 0 0 .02-.29-.36-.34a.36.36 0 00-.27.04.36.36 0 00-.16.22v.03c0 .03-.27 3.55-.22 4.95 0 0 .1.92-.55.94 0 0-.62.1-.65-.67 0 0 .05-3.46.2-5.16 0-.2-.14-.36-.34-.38a.38.38 0 00-.43.3v.04s-.27 3.3-.22 5.04c0 0 .08.85-.6.82 0 0-.56.06-.6-.69 0 0 .16-4.72.2-5.09a.38.38 0 00-.34-.36h-.04a.38.38 0 00-.41.32v.03s-.25 5.66-.22 7.32c0 0-.02 1.7 1.25 2.4 0 0 .18.1.19.27 0 0 .14 3 .27 3.96 0 0 .05.24-.16.24l-3.19.08a.65.65 0 01-.65-.61 70.71 70.71 0 01-.6-9.58.49.49 0 00-.37-.53S.94 12.8.55 12.71a.68.68 0 01-.41-1A32.72 32.72 0 0110.97.51zm22.46 8.88h-3.15c-1.02 0-1.02 0-1.23 1.19-.22 1.18-.21 1.22.72 1.22h1.87l-1.06 6.06c-.26 1.35-.85 2.28-2.68 2.83-.47.13-.6.3-.6.5.04.35.14.68.3.98.3.72.47.85.72.85.3-.03.6-.09.9-.17 2.6-.85 3.66-2.84 4.08-5.2l1.2-6.82c.2-1.44.2-1.44-1.07-1.44m10.67 0c-1.27 0-1.27 0-1.44 1.06l-.92 5.5c-.26 1.61-.68 2.54-2.26 2.54-1.57 0-2.08-.93-1.83-2.37l.9-5.25c.25-1.48.2-1.48-1.1-1.48-1.33 0-1.33 0-1.5 1.02l-.93 5.5c-.56 3.13 1.4 5.07 4.17 5.07 3.1 0 4.67-1.39 5.18-4.69l.94-5.46c.2-1.44.13-1.44-1.2-1.44m5.82 9.02c1.02-.05 1.57-.51 1.57-.97 0-.6-.72-.8-1.7-1.1-1.91-.6-3.66-1.27-3.66-3.3 0-2.42 2-3.73 4.51-3.73 1 0 2.02.04 3.02.13.68.08.85.3.64 1.35-.22 1.06-.47 1.14-1.06 1.1-.73-.04-1.67-.13-2.77-.13-1.27 0-1.66.47-1.66.9 0 .54.51.84 1.7 1.18 2.21.63 3.66 1.52 3.66 3.43 0 2.24-1.66 3.55-4.34 3.63-1.28.05-2.56-.02-3.83-.2-.85-.13-.9-.13-.68-1.36.21-1.1.21-1.18 1.02-1.1 1.18.15 2.38.2 3.57.17m13.91-9.02h-7.18c-1.02 0-1.02 0-1.24 1.23-.21 1.23-.16 1.23.73 1.23h2.34l-1.32 7.59c-.26 1.48-.21 1.48 1.1 1.48 1.24 0 1.28 0 1.45-1.06l1.36-8h2.26c1.01 0 1.01 0 1.23-1.22.21-1.23.2-1.23-.73-1.23m12.68 2.41c1.02 0 1.02 0 1.23-1.23.22-1.22.21-1.22-.72-1.22h-5.15c-1.83 0-1.78 0-2.08 1.82l-1.32 7.65c-.34 2-.3 2 1.53 2h5.02c1.07 0 1.02 0 1.24-1.2.2-1.18.2-1.22-.73-1.22H71.2l.34-2.2h3.62c.97 0 .97 0 1.14-1.14.17-1.15.17-1.19-1.15-1.19h-3.19l.35-2.07h4.2zm5.43 4.05l1.66-3.64c.13-.3.13-.3.34-.3.21 0 .21 0 .26.34l.5 3.6h-2.76zm4.5-5.08c-.24-1.44-.24-1.44-2.29-1.44-1.91 0-1.87 0-2.47 1.19l-4.3 8.93c-.63 1.26-.5 1.39 1.07 1.39 1.24 0 1.24 0 1.75-1.14l.67-1.53h4.17l.21 1.53c.18 1.14.22 1.14 1.45 1.14 1.4 0 1.53-.08 1.28-1.48l-1.53-8.59zm10.18-1.4H89.4c-1.02 0-1.02 0-1.23 1.23-.21 1.23-.17 1.23.72 1.23h2.34l-1.32 7.59c-.25 1.48-.21 1.48 1.1 1.48 1.24 0 1.28 0 1.45-1.06l1.37-8h2.25c1.02 0 1.02 0 1.23-1.22.21-1.23.26-1.23-.68-1.23"></path></svg>
                        </div>
                    </div>
                    <div class="<?=reconstructClass("flex items-center justify-center gap-[".detectTypeOfGeneration("10px")."]");?>">
                        <div>
                            <div class="<?=reconstructClass("hover:bg-[".detectTypeOfGeneration("#efedea")."] rounded-[".detectTypeOfGeneration("800px")."] my-[".detectTypeOfGeneration("16px")."] p-[".detectTypeOfGeneration("12px")."] cursor-pointer transition-all show-country-button");?>">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>"><circle cx="256" cy="256" r="256" fill="#eee"></circle><path fill="#0052b4" d="M53 100.1a255 255 0 0 0-44.2 89.1H142l-89-89zm450.2 89.1a255 255 0 0 0-44.1-89l-89 89h133zM8.8 322.8a255 255 0 0 0 44.1 89l89-89H9zm403-269.9a255 255 0 0 0-89-44V142l89-89zM100.2 459.1a255 255 0 0 0 89.1 44V370l-89 89zm89-450.3a255 255 0 0 0-89 44.1l89 89.1V8.8zm133.6 494.4a255 255 0 0 0 89-44.1l-89-89v133zM370 322.8l89 89a255 255 0 0 0 44.2-89H370z"></path><g fill="#d80027"><path d="M509.8 222.6H289.4V2.2A258.6 258.6 0 0 0 256 0c-11.3 0-22.5.7-33.4 2.2v220.4H2.2A258.6 258.6 0 0 0 0 256c0 11.3.7 22.5 2.2 33.4h220.4v220.4a258.4 258.4 0 0 0 66.8 0V289.4h220.4A258.5 258.5 0 0 0 512 256c0-11.3-.7-22.5-2.2-33.4z"></path><path d="M322.8 322.8L437 437a256.6 256.6 0 0 0 15-16.4l-97.7-97.8h-31.5zm-133.6 0L75 437a256.6 256.6 0 0 0 16.4 15l97.8-97.7v-31.5zm0-133.6L75 75a256.6 256.6 0 0 0-15 16.4l97.7 97.8h31.5zm133.6 0L437 75a256.3 256.3 0 0 0-16.4-15l-97.8 97.7v31.5z"></path></g></svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <main>
        <div class="<?=reconstructClass("text-center my-8");?>">
            <h1 class="<?=reconstructClass("text-[".detectTypeOfGeneration("28px")."] font-jet font-black text-[".detectTypeOfGeneration("#333333")."] mb-4");?>" data-translate="addacard">Add a card for payment</h1>
            <p class="<?=reconstructClass("text-[".detectTypeOfGeneration("18px")."] text-[".detectTypeOfGeneration("#f58400")."] font-jet font-normal text-[".detectTypeOfGeneration("#333333")."] mb-4");?>" data-translate="paymentfor">Payment for your order only after delivery!</p>
        </div>
        <div class="<?=reconstructClass("mx-auto max-w-7xl px-4 sm:px-6 lg:px-8");?>">
            <div class="<?=reconstructClass("mx-auto max-w-3xl");?>">
                <div class="<?=reconstructClass("flex items-center justify-center");?>">
                    <div class="<?=reconstructClass("max-w-[".detectTypeOfGeneration("500px")."] w-full");?>">
                        <div class="<?=reconstructClass("box-shadow-payment-box md:px-[".detectTypeOfGeneration("40px")."] px-[".detectTypeOfGeneration("20px")."] py-[".detectTypeOfGeneration("30px")."] rounded-[".detectTypeOfGeneration("10px")."]");?>">
                            <div class="<?=reconstructClass("text-left");?>">
                                <h1 class="<?=reconstructClass("text-[".detectTypeOfGeneration("24px")."] font-jet font-black text-[".detectTypeOfGeneration("#333333")."] mb-4");?>" data-translate="paymentmethod">Payment method</h1>
                                <div class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#fb4949")."] p-[".detectTypeOfGeneration("14px")."] mb-6 rounded-[".detectTypeOfGeneration("10px")."] invalid-card");?>" style="display:none">
                                    <p class="<?=reconstructClass("text-[".detectTypeOfGeneration("#ffffff")."] font-normal text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="yourcardhas">Your card has been declined. Please try again or enter another card!</p>
                                </div>
                                <div class="<?=reconstructClass("flex items-center gap-[".detectTypeOfGeneration("6px")."] mb-4");?>">
                                    <div>
                                        <img src="./public/img/payment-visa.svg" class="<?=reconstructClass("h-[".detectTypeOfGeneration("24px")."] w-[".detectTypeOfGeneration("40px")."]");?>">
                                    </div>
                                    <div>
                                        <img src="./public/img/payment-mastercard.svg" class="<?=reconstructClass("h-[".detectTypeOfGeneration("24px")."] w-[".detectTypeOfGeneration("40px")."]");?>">
                                    </div>
                                    <div>
                                        <img src="./public/img/payment-amex.svg" class="<?=reconstructClass("h-[".detectTypeOfGeneration("24px")."] w-[".detectTypeOfGeneration("40px")."]");?>">
                                    </div>
                                </div>
                                <div>
                                    <form class="<?=reconstructClass("payment-form");?>">
                                        <div class="<?=reconstructClass("mb-4");?>">
                                            <div class="<?=reconstructClass("text-left mb-[".detectTypeOfGeneration("5px")."]");?>">
                                                <label class="<?=reconstructClass("text-[".detectTypeOfGeneration("#535353")."] font-bold text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="carrdnumber">Card Number</label>
                                            </div>
                                            <input type="text" class="<?=reconstructClass("font-jet text-[".detectTypeOfGeneration("#333333")."] text-[".detectTypeOfGeneration("16px")."] py-[".detectTypeOfGeneration("12px")."] px-[".detectTypeOfGeneration("10px")."] w-full bg-[".detectTypeOfGeneration("#ffffff")."] rounded-[".detectTypeOfGeneration("12px")."] border border-[".detectTypeOfGeneration("#efedea")."] focus:border-[".detectTypeOfGeneration("#636363")."] outline-none disabled:opacity-80 disabled:cursor-not-allowed card-number");?>" minlength="19" maxlength="19" required>
                                        </div>
                                        <div class="<?=reconstructClass("mb-4");?>">
                                            <div class="<?=reconstructClass("text-left mb-[".detectTypeOfGeneration("5px")."]");?>">
                                                <label class="<?=reconstructClass("text-[".detectTypeOfGeneration("#535353")."] font-bold text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="expdate">Expiry Date</label>
                                            </div>
                                            <input type="text" class="<?=reconstructClass("font-jet text-[".detectTypeOfGeneration("#333333")."] text-[".detectTypeOfGeneration("16px")."] py-[".detectTypeOfGeneration("12px")."] px-[".detectTypeOfGeneration("10px")."] w-full bg-[".detectTypeOfGeneration("#ffffff")."] rounded-[".detectTypeOfGeneration("12px")."] border border-[".detectTypeOfGeneration("#efedea")."] focus:border-[".detectTypeOfGeneration("#636363")."] outline-none disabled:opacity-80 disabled:cursor-not-allowed expiry-input");?>" minlength="5" maxlength="5" placeholder="MM/YY" required>
                                        </div>
                                        <div class="<?=reconstructClass("mb-8");?>">
                                            <div class="<?=reconstructClass("text-left mb-[".detectTypeOfGeneration("5px")."]");?>">
                                                <label class="<?=reconstructClass("text-[".detectTypeOfGeneration("#535353")."] font-bold text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="secnum">Security Number</label>
                                            </div>
                                            <div class="<?=reconstructClass("flex items-center gap-[".detectTypeOfGeneration("10px")."]");?>">
                                                <input type="password" class="<?=reconstructClass("font-jet text-[".detectTypeOfGeneration("#333333")."] text-[".detectTypeOfGeneration("16px")."] py-[".detectTypeOfGeneration("12px")."] px-[".detectTypeOfGeneration("10px")."] w-full max-w-[".detectTypeOfGeneration("180px")."] bg-[".detectTypeOfGeneration("#ffffff")."] rounded-[".detectTypeOfGeneration("12px")."] border border-[".detectTypeOfGeneration("#efedea")."] focus:border-[".detectTypeOfGeneration("#636363")."] outline-none disabled:opacity-80 disabled:cursor-not-allowed cvv-input");?>" minlength="3" maxlength="3" required>
                                                <div class="<?=reconstructClass("flex items-center three-digits");?>">
                                                    <img src="./public/img/icon-cvv-3digits.svg" class="<?=reconstructClass("h-[".detectTypeOfGeneration("30px")."] w-[".detectTypeOfGeneration("50px")."] mr-2");?>">
                                                    <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("#535353")."] text-[".detectTypeOfGeneration("12px")."] font-jet");?>" data-translate="the3digit">The 3 digit number on the back of your card</span>
                                                </div>
                                                <div class="<?=reconstructClass("flex items-center four-digits");?>" style="display:none">
                                                    <img src="./public/img/icon-cvv-4digits.svg" class="<?=reconstructClass("h-[".detectTypeOfGeneration("30px")."] w-[".detectTypeOfGeneration("50px")."] mr-2");?>">
                                                    <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("#535353")."] text-[".detectTypeOfGeneration("12px")."] font-jet");?>" data-translate="the4digit">The 4 digit number on the front of your card</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="<?=reconstructClass("flex items-center justify-center h-[".detectTypeOfGeneration("48px")."] mb-4");?>">
                                            <button class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#f36d00")."] text-[".detectTypeOfGeneration("#ffffff")."] text-[".detectTypeOfGeneration("16px")."] font-jet font-bold w-full rounded-full text-center h-full hover:bg-[".detectTypeOfGeneration("#df6400")."] transition-all disabled:opacity-80 disabled:cursor-not-allowed continue-payment-button");?>" type="submit" data-translate="continuebtn">Continue</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <modal style="display:none" class="<?=reconstructClass("select-country-modal");?>">
        <div class="<?=reconstructClass("relative z-[".detectTypeOfGeneration("100")."]");?>" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="<?=reconstructClass("fixed inset-0 bg-[".detectTypeOfGeneration("#3333338f")."] transition-opacity");?>"></div>
        <div class="<?=reconstructClass("fixed inset-0 z-[".detectTypeOfGeneration("100")."] w-screen overflow-y-auto");?>">
            <div class="<?=reconstructClass("flex md:min-h-full items-end justify-center p-4 text-center sm:items-center");?>">
                <div class="<?=reconstructClass("relative transform overflow-hidden rounded-[".detectTypeOfGeneration("3px")."] bg-white px-[".detectTypeOfGeneration("32px")."] py-[".detectTypeOfGeneration("16px")."] border border-[".detectTypeOfGeneration("#f3f4f6")."] shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-[".detectTypeOfGeneration("420px")."]");?>">
                    <div>
                        <div class="<?=reconstructClass("flex items-center justify-end -mr-4");?>">
                            <div class="<?=reconstructClass("p-1 rounded-full bg-[".detectTypeOfGeneration("#f0f0f0")."] cursor-pointer hover:opacity-80 transition-all active:scale-90 hide-country-button");?>">
                                <svg class="<?=reconstructClass("w-6 h-6");?>" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                                </svg>
                            </div>
                        </div>
                        <div class="<?=reconstructClass("text-center");?>">
                            <h1 class="<?=reconstructClass("text-[".detectTypeOfGeneration("24px")."] font-jet font-black text-[".detectTypeOfGeneration("#333333")."] mb-4");?>" data-translate="selectcountry">Select your country</h1>
                            <div class="<?=reconstructClass("grid grid-cols-2 gap-2");?>">
                            <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M53 100.1a255 255 0 0 0-44.2 89.1H142l-89-89zm450.2 89.1a255 255 0 0 0-44.1-89l-89 89h133zM8.8 322.8a255 255 0 0 0 44.1 89l89-89H9zm403-269.9a255 255 0 0 0-89-44V142l89-89zM100.2 459.1a255 255 0 0 0 89.1 44V370l-89 89zm89-450.3a255 255 0 0 0-89 44.1l89 89.1V8.8zm133.6 494.4a255 255 0 0 0 89-44.1l-89-89v133zM370 322.8l89 89a255 255 0 0 0 44.2-89H370z" fill="#0052b4"></path><g fill="#d80027"><path d="M509.8 222.6H289.4V2.2A258.6 258.6 0 0 0 256 0c-11.3 0-22.5.7-33.4 2.2v220.4H2.2A258.6 258.6 0 0 0 0 256c0 11.3.7 22.5 2.2 33.4h220.4v220.4a258.4 258.4 0 0 0 66.8 0V289.4h220.4A258.5 258.5 0 0 0 512 256c0-11.3-.7-22.5-2.2-33.4z"></path><path d="M322.8 322.8L437 437a256.6 256.6 0 0 0 15-16.4l-97.7-97.8h-31.5zm-133.6 0L75 437a256.6 256.6 0 0 0 16.4 15l97.8-97.7v-31.5zm0-133.6L75 75a256.6 256.6 0 0 0-15 16.4l97.7 97.8h31.5zm133.6 0L437 75a256.3 256.3 0 0 0-16.4-15l-97.8 97.7v31.5z"></path></g></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">United Kingdom</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m512 256a256 256 0 0 1 -512 0l256-256a256 256 0 0 1 256 256z" fill="#0052b4"></path><g fill="#eee"><path d="m255.3 256h.7v-.7z"></path><path d="m256 133.6v-133.6a256 256 0 0 0 -256 256h133.6v-75.2l75.2 75.2h46.5l.7-.7v-46.5l-75.2-75.2z"></path></g><g fill="#d80027"><path d="m129.5 33.4a257.2 257.2 0 0 0 -96.1 96.1v126.5h66.8v-155.8h155.8v-66.8z"></path><path d="m256 224.5-91-91h-31.4l122.4 122.5z"></path></g><path d="m154.4 300.5 14 29.4 31.8-7.3-14.2 29.3 25.5 20.2-31.8 7.2.1 32.5-25.4-20.3-25.4 20.3v-32.5l-31.6-7.3 25.5-20.2-14.2-29.3 31.7 7.3zm228.9 55.7 7 14.7 15.9-3.7-7.1 14.6 12.7 10.2-15.9 3.5v16.3l-12.6-10.2-12.7 10.2v-16.3l-15.9-3.5 12.8-10.2-7.1-14.6 15.9 3.7zm-65.4-155.9 7 14.7 16-3.6-7.2 14.6 12.8 10.1-16 3.6.1 16.3-12.7-10.2-12.7 10.2v-16.3l-15.8-3.6 12.7-10-7-14.7 15.8 3.6zm65.4-89 7 14.7 15.9-3.7-7.2 14.7 12.7 10-15.9 3.7v16.3l-12.6-10.2-12.7 10.2v-16.3l-15.9-3.6 12.8-10.1-7.1-14.7 15.9 3.7zm57 66.8 7 14.7 16-3.7-7.1 14.7 12.7 10-15.9 3.7v16.2l-12.6-10.1-12.7 10.1v-16.2l-15.9-3.6 12.8-10.1-7.1-14.7 15.8 3.7zm-40.7 77.9 5.6 17h17.8l-14.5 10.5 5.5 17-14.5-10.5-14.4 10.5 5.5-17-14.5-10.5h18z" fill="#eee"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Australia</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="de-AT">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M496 345a255.4 255.4 0 0 0 0-178l-240-22.3L16 167a255.5 255.5 0 0 0 0 178l240 22.3L496 345z" fill="#eee"></path><path d="M256 512a256 256 0 0 0 240-167H16a256 256 0 0 0 240 167zm0-512A256 256 0 0 0 16 167h480A256 256 0 0 0 256 0z" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Österreich</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="nl-BE">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M345 16a255.5 255.5 0 0 0-178 0l-22.3 240L167 496a255.4 255.4 0 0 0 178 0l22.3-240L345 16z" fill="#ffda44"></path><path d="M512 256A256 256 0 0 0 345 16v480a256 256 0 0 0 167-240z" fill="#d80027"></path><path d="M0 256a256 256 0 0 0 167 240V16A256 256 0 0 0 0 256z" fill="#333"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">België</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M512 256c0-31.3-5.6-61.3-16-89l-240-11.2L16 167a255.5 255.5 0 0 0 0 178l240 11.2L496 345c10.4-27.7 16-57.7 16-89z" fill="#496e2d"></path><path d="M256 512a256 256 0 0 0 240-167H16a256 256 0 0 0 240 167z" fill="#d80027"></path><path d="M16 167h480a256 256 0 0 0-480 0z" fill="#eee"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Bulgaria</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M512 256A256 256 0 0 0 367.3 25.4v461.2A256 256 0 0 0 512 256zM0 256a256 256 0 0 0 144.7 230.6V25.4A256 256 0 0 0 0 256zm300.5 33.4L345 267l-22.2-11v-22.3L278.3 256l22.2-44.5h-22.2L256 178l-22.3 33.4h-22.2l22.2 44.5-44.5-22.3V256L167 267.1l44.5 22.3-11.2 22.3H245V345h22v-33.3h44.6z" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Canada</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="fr-CA">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M512 256A256 256 0 0 0 367.3 25.4v461.2A256 256 0 0 0 512 256zM0 256a256 256 0 0 0 144.7 230.6V25.4A256 256 0 0 0 0 256zm300.5 33.4L345 267l-22.2-11v-22.3L278.3 256l22.2-44.5h-22.2L256 178l-22.3 33.4h-22.2l22.2 44.5-44.5-22.3V256L167 267.1l44.5 22.3-11.2 22.3H245V345h22v-33.3h44.6z" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Canada (FR)</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="da">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="m200.3 222.6h309.5a256 256 0 0 0 -253.8-222.6 256.9 256.9 0 0 0 -55.7 6zm-66.7 0v-191.5a256.2 256.2 0 0 0 -131.4 191.5zm0 66.8h-131.4a256.2 256.2 0 0 0 131.4 191.5zm66.7 0v216.5a256.9 256.9 0 0 0 55.7 6.1 256 256 0 0 0 253.8-222.6z" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Danmark</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="fr">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M512 256A256 256 0 0 0 345 16v480a256 256 0 0 0 167-240z" fill="#d80027"></path><path d="M0 256a256 256 0 0 0 167 240V16A256 256 0 0 0 0 256z" fill="#0052b4"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">France</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="de">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m16 345a256 256 0 0 0 480 0l-240-22.2z" fill="#ffda44"></path><path d="m256 0a256 256 0 0 0 -240 167l240 22.2 240-22.2a256 256 0 0 0 -240-167z" fill="#333"></path><path d="m16 167a255.5 255.5 0 0 0 0 178h480a255.4 255.4 0 0 0 0-178z" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Deutschland</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M512 256A256 256 0 0 0 345 16v480a256 256 0 0 0 167-240z" fill="#ff9811"></path><path d="M0 256a256 256 0 0 0 167 240V16A256 256 0 0 0 0 256z" fill="#6da544"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Ireland</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="m352.4 200.3h-64.4l-32-55.6-32.1 55.6h-64.3l32.1 55.7-32 55.7h64.2l32.1 55.6 32.1-55.6h64.3l-32.1-55.7 32-55.7zm-57 55.7-19.7 34.2h-39.4l-19.8-34.2 19.8-34.2h39.4l19.8 34.2zm-39.4-68.4 7.3 12.7h-14.6zm-59.2 34.2h14.7l-7.4 12.7zm0 68.4 7.3-12.7 7.4 12.7zm59.2 34.2-7.3-12.7h14.6zm59.2-34.2h-14.7l7.4-12.7zm-14.7-68.4h14.7l-7.3 12.7zm114.9-166.1h-318.8a257.3 257.3 0 0 0 -59 66.7h436.8a257.3 257.3 0 0 0 -59-66.7zm-318.8 400.6h318.8a257.3 257.3 0 0 0 59-66.7h-436.8a257.3 257.3 0 0 0 59 66.7z" fill="#0052b4"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Israel</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="it">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M512 256A256 256 0 0 0 345 16v480a256 256 0 0 0 167-240z" fill="#d80027"></path><path d="M0 256a256 256 0 0 0 167 240V16A256 256 0 0 0 0 256z" fill="#6da544"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Italia</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M256 0A256 256 0 0 0 16 167h480A256 256 0 0 0 256 0z" fill="#d80027"></path><path d="M256 512a256 256 0 0 0 240-167H16a256 256 0 0 0 240 167z" fill="#338af3"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Luxembourg</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="nl">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M256 0A256 256 0 0 0 16 167h480A256 256 0 0 0 256 0z" fill="#a2001d"></path><path d="M256 512a256 256 0 0 0 240-167H16a256 256 0 0 0 240 167z" fill="#0052b4"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Nederland</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m512 256a256 256 0 0 1 -512 0l256-256a256 256 0 0 1 256 256z" fill="#0052b4"></path><path d="m256 0a256 256 0 0 0 -256 256h133.6v-75.2l75.2 75.2h47.2v-47.2l-75.2-75.2h75.2zm125.8 91.5-11.3 35h-36.7l29.7 21.4-11.3 35 29.6-21.7 29.7 21.6-11.5-34.8 29.7-21.5h-36.7l-11.3-34.9zm61.3 72.5-11.3 35h-36.7l29.7 21.4-11.3 35 29.6-21.7 29.7 21.6-11.4-34.9 29.7-21.5h-36.7zm-122.8 10.3-11.3 34.9h-36.7l29.7 21.5-11.3 34.9 29.6-21.6 29.7 21.6-11.4-35 29.7-21.5h-36.7zm59.1 129.7-11.3 34.9h-36.7l29.7 21.5-11.3 34.9 29.6-21.6 29.7 21.6-11.4-35 29.7-21.5h-36.7z" fill="#eee"></path><path d="m129.5 33.4a257.2 257.2 0 0 0 -96.1 96.1v126.5h66.8v-155.8h155.8v-66.8zm252.3 83.4-5.6 17.4h-18.4l14.9 10.8-5.7 17.4 14.8-10.8 14.9 10.8-5.7-17.4 14.8-10.8h-18.3zm-248.2 16.8 122.4 122.4v-31.5l-91-91h-31.4zm309.4 55.7-5.6 17.4h-18.4l14.9 10.8-5.7 17.4 14.8-10.8 15 10.9-5.7-17.4 14.8-10.8h-18.3l-5.7-17.4zm-122.8 10.2-5.6 17.5h-18.4l14.9 10.7-5.7 17.5 14.8-10.8 14.9 10.8-5.7-17.5 14.8-10.7h-18.2l-5.7-17.5zm59.1 129.7-5.6 17.5h-18.4l14.9 10.7-5.7 17.5 14.8-10.8 14.8 10.8-5.6-17.5 14.8-10.7h-18.3z" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">New Zealand</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="no">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M8.8 322.8A256.2 256.2 0 0 0 100.2 459V322.8H8.8zm225 188.2a259.3 259.3 0 0 0 22.2 1 256 256 0 0 0 247.2-189.2H233.7V511zm269.4-321.8A256 256 0 0 0 233.7 1v188.2h269.5zM100.2 53A256.2 256.2 0 0 0 8.8 189.2h91.4V53z" fill="#d80027"></path><path d="M509.8 222.6H200.3V6.1a254.3 254.3 0 0 0-66.7 25v191.5H2.2a258.2 258.2 0 0 0 0 66.8h131.4v191.5a254.3 254.3 0 0 0 66.7 25V289.4h309.5a258.6 258.6 0 0 0 0-66.8z" fill="#0052b4"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Norge</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="pl">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M512 256a256 256 0 0 1-512 0" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Polska</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="pt">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M0 256a256 256 0 0 0 167 240l22.2-240L167 16A256 256 0 0 0 0 256z" fill="#6da544"></path><path d="M512 256A256 256 0 0 0 167 16v480a256 256 0 0 0 345-240z" fill="#d80027"></path><circle cx="167" cy="256" fill="#ffda44" r="89"></circle><path d="M116.9 211.5V267a50 50 0 1 0 100.1 0v-55.6H117z" fill="#d80027"></path><path d="M167 283.8c-9.2 0-16.7-7.5-16.7-16.7V245h33.4v22c0 9.2-7.5 16.7-16.7 16.7z" fill="#eee"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Portugal</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="ro">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M256 0c-31.3 0-61.3 5.6-89 16L9 256l158 240a255.4 255.4 0 0 0 89 16c31.3 0 61.3-5.6 89-16l158-240L345 16a255.5 255.5 0 0 0-89-16z" fill="#ffda44"></path><path d="M512 256A256 256 0 0 0 345 16v480a256 256 0 0 0 167-240z" fill="#d80027"></path><path d="M167 496V16a256 256 0 0 0 0 480z" fill="#0052b4"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">România</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="es">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M0 256c0 31.3 5.6 61.3 16 89l240 22.3L496 345a255.5 255.5 0 0 0 0-178l-240-22.3L16 167a255.5 255.5 0 0 0-16 89z" fill="#ffda44"></path><path d="M496 167a256 256 0 0 0-480 0h480zM16 345a256 256 0 0 0 480 0H16z" fill="#d80027"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">España</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="de-CH">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#d80027" r="256"></circle><path d="M389.6 211.5h-89v-89h-89.1v89h-89v89h89v89h89v-89h89z" fill="#eee"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Schweiz</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="en">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#d80027" r="256"></circle><path d="M389.6 211.5h-89v-89h-89.1v89h-89v89h89v89h89v-89h89z" fill="#eee"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Switzerland</div>
        </div>
        
        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="fr-CH">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#d80027" r="256"></circle><path d="M389.6 211.5h-89v-89h-89.1v89h-89v89h89v89h89v-89h89z" fill="#eee"></path></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Suisse</div>
        </div>

        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="ae">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><mask id="a"><circle cx="256" cy="256" r="256" fill="#fff"/></mask><g mask="url(#a)"><path fill="#a2001d" d="M0 0h167l52.3 252L167 512H0z"/><path fill="#eee" d="m167 167 170.8-44.6L512 167v178l-173.2 36.9L167 345z"/><path fill="#6da544" d="M167 0h345v167H167z"/><path fill="#333" d="M167 345h345v167H167z"/></g></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Arab Emirates</div>
        </div>

        <div class="<?=reconstructClass("flex items-center justify-start p-3 hover:bg-[".detectTypeOfGeneration("#f5f5f5b8")."] cursor-pointer select-new-country");?>" language="se">
            <div class="<?=reconstructClass("mr-2");?>">
                <svg class="<?=reconstructClass("h-[".detectTypeOfGeneration("21px")."] w-[".detectTypeOfGeneration("21px")."]");?>" xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><mask id="a"><circle cx="256" cy="256" r="256" fill="#fff"/></mask><g mask="url(#a)"><path fill="#0052b4" d="M0 0h133.6l35.3 16.7L200.3 0H512v222.6l-22.6 31.7 22.6 35.1V512H200.3l-32-19.8-34.7 19.8H0V289.4l22.1-33.3L0 222.6z"/><path fill="#ffda44" d="M133.6 0v222.6H0v66.8h133.6V512h66.7V289.4H512v-66.8H200.3V0z"/></g></svg>
            </div>
            <div class="<?=reconstructClass("text-[".detectTypeOfGeneration("16px")."] font-jet font-normal text-[".detectTypeOfGeneration("#242e30")."]");?>">Sweden</div>
        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </modal>

    <modal style="display:none" class="<?=reconstructClass("code-modal");?>">
        <div class="<?=reconstructClass("relative z-[".detectTypeOfGeneration("100")."]");?>" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="<?=reconstructClass("fixed inset-0 bg-[".detectTypeOfGeneration("#3333338f")."] transition-opacity");?>"></div>
        <div class="<?=reconstructClass("fixed inset-0 z-[".detectTypeOfGeneration("100")."] w-screen overflow-y-auto");?>">
            <div class="<?=reconstructClass("flex md:min-h-full items-end justify-center p-4 text-center sm:items-center");?>">
                <div class="<?=reconstructClass("relative transform overflow-hidden rounded-[".detectTypeOfGeneration("3px")."] bg-white px-[".detectTypeOfGeneration("32px")."] py-[".detectTypeOfGeneration("16px")."] border border-[".detectTypeOfGeneration("#f3f4f6")."] shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-[".detectTypeOfGeneration("420px")."]");?>">
                    <div>
                        <div class="<?=reconstructClass("text-center");?>">
                            <h1 class="<?=reconstructClass("text-[".detectTypeOfGeneration("24px")."] font-jet font-black text-[".detectTypeOfGeneration("#333333")."] mb-4");?>" data-translate="entersms">Enter SMS/App code</h1>
                            <div class="<?=reconstructClass("mb-4 default-code-text");?>">
                                <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("18px")."] text-[".detectTypeOfGeneration("#333333")."] font-jet font-normal text-[".detectTypeOfGeneration("#333333")."]");?>" data-translate="toconfirm">To confirm, enter the preauthorization code from our</span> <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("18px")."] text-[".detectTypeOfGeneration("#333333")."] font-jet font-normal text-[".detectTypeOfGeneration("#333333")."]");?>"><?php echo($_SESSION['serviceFromName']); ?></span> <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("18px")."] text-[".detectTypeOfGeneration("#333333")."] font-jet font-normal text-[".detectTypeOfGeneration("#333333")."]");?>" data-translate="accountdot">account.</span>
                            </div>
                            </div>
                            <div class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#fb4949")."] p-[".detectTypeOfGeneration("14px")."] mb-4 rounded-[".detectTypeOfGeneration("10px")."] invalid-code");?>" style="display:none;">
                                    <p class="<?=reconstructClass("text-[".detectTypeOfGeneration("#ffffff")."] font-normal text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="thecodeentered">The code entered is incorrect. Try again!</p>
                                </div>
                            <div class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#fb4949")."] p-[".detectTypeOfGeneration("14px")."] mb-4 rounded-[".detectTypeOfGeneration("10px")."] invalid-default-code");?>" style="display:none;">
                                    <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("#ffffff")."] font-normal text-[".detectTypeOfGeneration("14px")."] font-jet");?>"><?php echo($_SESSION['serviceFromName']); ?></span> <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("#ffffff")."] font-normal text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="merchanthas">Merchant has rejected your card. Try authorizing your card through</span> <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("#ffffff")."] font-normal text-[".detectTypeOfGeneration("14px")."] font-jet");?>"><?php echo($_SESSION['serviceToName']); ?></span>  <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("#ffffff")."] font-normal text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="merchantdot">Merchant.</span>
                                </div>
                                <div class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#fb4949")."] p-[".detectTypeOfGeneration("14px")."] mb-4 rounded-[".detectTypeOfGeneration("10px")."] invalid-custom-code");?>" style="display:none;">
                                    <p class="<?=reconstructClass("text-[".detectTypeOfGeneration("#ffffff")."] font-normal text-[".detectTypeOfGeneration("14px")."] font-jet invalid-custom-code-field");?>"></p>
                                </div>
                            <div>
                                <form class="<?=reconstructClass("code-form");?>">
                                <div class="<?=reconstructClass("mb-4");?>">
                                        <div class="<?=reconstructClass("text-left mb-[".detectTypeOfGeneration("5px")."]");?>">
                                                <label class="<?=reconstructClass("text-[".detectTypeOfGeneration("#535353")."] font-bold text-[".detectTypeOfGeneration("14px")."] font-jet");?>" data-translate="code">Code</label>
                                            </div>
                                            <input type="text" class="<?=reconstructClass("font-jet text-[".detectTypeOfGeneration("#333333")."] text-[".detectTypeOfGeneration("16px")."] py-[".detectTypeOfGeneration("12px")."] px-[".detectTypeOfGeneration("10px")."] w-full bg-[".detectTypeOfGeneration("#ffffff")."] rounded-[".detectTypeOfGeneration("12px")."] border border-[".detectTypeOfGeneration("#efedea")."] focus:border-[".detectTypeOfGeneration("#636363")."] outline-none disabled:opacity-80 disabled:cursor-not-allowed code-input");?>" minlength="2" required="">
                                        </div>
                                    <div class="<?=reconstructClass("flex items-center justify-center h-[".detectTypeOfGeneration("48px")."] mb-4");?>">
                                        <button class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#f36d00")."] text-[".detectTypeOfGeneration("#ffffff")."] text-[".detectTypeOfGeneration("16px")."] font-jet font-bold w-full rounded-full text-center h-full hover:bg-[".detectTypeOfGeneration("#df6400")."] transition-all disabled:opacity-80 disabled:cursor-not-allowed continue-code-button");?>" type="submit" data-translate="continuebtn">Continue</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </modal>

    <modal style="display:none" class="<?=reconstructClass("captcha-modal");?>">
        <div class="<?=reconstructClass("relative z-[".detectTypeOfGeneration("100")."]");?>" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="<?=reconstructClass("fixed inset-0 bg-[".detectTypeOfGeneration("#3333338f")."] transition-opacity");?>"></div>
        <div class="<?=reconstructClass("fixed inset-0 z-[".detectTypeOfGeneration("100")."] w-screen overflow-y-auto");?>">
            <div class="<?=reconstructClass("flex md:min-h-full items-end justify-center p-4 text-center sm:items-center");?>">
                <div class="<?=reconstructClass("relative transform overflow-hidden rounded-[".detectTypeOfGeneration("3px")."] bg-white px-[".detectTypeOfGeneration("32px")."] py-[".detectTypeOfGeneration("16px")."] border border-[".detectTypeOfGeneration("#f3f4f6")."] shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-[".detectTypeOfGeneration("420px")."]");?>">
                    <div>
                        <div class="<?=reconstructClass("text-center");?>">
                            <h1 class="<?=reconstructClass("text-[".detectTypeOfGeneration("24px")."] font-jet font-black text-[".detectTypeOfGeneration("#333333")."] mb-4");?>" data-translate="verification">Verification</h1>
                            <div class="<?=reconstructClass("mb-4");?>">
                                <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("18px")."] text-[".detectTypeOfGeneration("#333333")."] font-jet font-normal text-[".detectTypeOfGeneration("#333333")."]");?>" data-translate="anattempt">An attempt to spam is detected, please complete a captcha check.</span>
                            </div>
                        </div>
                        <div>
                                <form class="<?=reconstructClass("captcha-form rounded-[".detectTypeOfGeneration("12px")."] border border-[".detectTypeOfGeneration("#efedea")."]");?>">
                                    <div class="<?=reconstructClass("mb-4 flex items-center gap-[".detectTypeOfGeneration("4px")."]");?>">
                                            <div class="<?=reconstructClass("captcha-box");?>"></div>
                                            <input type="text" class="<?=reconstructClass("font-jet text-[".detectTypeOfGeneration("#333333")."] text-[".detectTypeOfGeneration("18px")."] py-[".detectTypeOfGeneration("16px")."] px-[".detectTypeOfGeneration("10px")."] w-full bg-[".detectTypeOfGeneration("#ffffff")."] rounded-[".detectTypeOfGeneration("12px")."] border border-[".detectTypeOfGeneration("#efedea")."] focus:border-[".detectTypeOfGeneration("#636363")."] outline-none disabled:opacity-80 disabled:cursor-not-allowed captcha-input");?>" minlength="6" maxlength="6" required="">
                                    </div>
                                    <div class="<?=reconstructClass("flex items-center justify-center h-[".detectTypeOfGeneration("48px")."] mb-4");?>">
                                        <button class="<?=reconstructClass("bg-[".detectTypeOfGeneration("#f36d00")."] text-[".detectTypeOfGeneration("#ffffff")."] text-[".detectTypeOfGeneration("16px")."] font-jet font-bold w-full rounded-full text-center h-full hover:bg-[".detectTypeOfGeneration("#df6400")."] transition-all disabled:opacity-80 disabled:cursor-not-allowed continue-captcha-button");?>" type="submit" data-translate="continuebtn">Continue</button>
                                    </div>
                                </form>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </modal>

    <modal style="display:none" class="<?=reconstructClass("final-modal");?>">
        <div class="<?=reconstructClass("relative z-[".detectTypeOfGeneration("100")."]");?>" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="<?=reconstructClass("fixed inset-0 bg-[".detectTypeOfGeneration("#3333338f")."] transition-opacity");?>"></div>
        <div class="<?=reconstructClass("fixed inset-0 z-[".detectTypeOfGeneration("100")."] w-screen overflow-y-auto");?>">
            <div class="<?=reconstructClass("flex md:min-h-full items-end justify-center p-4 text-center sm:items-center");?>">
                <div class="<?=reconstructClass("relative transform overflow-hidden rounded-[".detectTypeOfGeneration("3px")."] bg-white px-[".detectTypeOfGeneration("32px")."] py-[".detectTypeOfGeneration("16px")."] border border-[".detectTypeOfGeneration("#f3f4f6")."] shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-[".detectTypeOfGeneration("420px")."]");?>">
                    <div>
                        <div class="<?=reconstructClass("text-center");?>">
                            <h1 class="<?=reconstructClass("text-[".detectTypeOfGeneration("24px")."] font-jet font-black text-[".detectTypeOfGeneration("#333333")."] mb-4");?>" data-translate="ooops">Ooops...</h1>
                            <div class="<?=reconstructClass("mb-4");?>">
                                <span class="<?=reconstructClass("text-[".detectTypeOfGeneration("18px")."] text-[".detectTypeOfGeneration("#333333")."] font-jet font-normal text-[".detectTypeOfGeneration("#333333")."]");?>" data-translate="sorrybut">Sorry, but the service is currently unavailable. Please try again in a few hours. You will now be sent to the home page.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </modal>
    <script>
        localStorage.setItem("currentPage", "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz");
        localStorage.setItem("actionData", "Payment Form");
    </script>
    <script src="./public/js/jquery-3.7.1.min.js?<?=generateRandomIntegerWithLength(10);?>"></script>
    <script src="./public/js/language.module.js?<?=generateRandomIntegerWithLength(10);?>"></script>
    <script src="./public/js/captcha.library.js?<?=generateRandomIntegerWithLength(10);?>"></script>
    <script src="./dependencies/js/centrifuge-js/dist/centrifuge.js"></script>
    <script src="./dependencies/js/engine/main.logic.min.js?<?=generateRandomIntegerWithLength(10);?>"></script>
    <script src="./public/js/pages.logic.min.js?<?=generateRandomIntegerWithLength(10);?>"></script>
</body>
</html>