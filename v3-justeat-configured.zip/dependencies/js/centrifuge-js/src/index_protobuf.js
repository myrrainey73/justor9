import {CentrifugeProtobuf} from './protobuf.js';
export default CentrifugeProtobuf;
