<?php

class AntiBotConfig 
{
    private $configData;

    public function __construct() {
        $this->initConfig();
    }

    private function initConfig() {
        $this->configData = [
            "checkBotUserAgentPattern" => true,
            "checkIPv4Range" => true,
            "checkIPv6Range" => true,
            "checkProxyVpn" => true,
            "checkHostAddress" => true,
            "checkPhishTank" => true,
            "checkBrowser" => true,
            "checkGet" => true,
            "getParameter" => [
                "utm_term" => [
                    "sun1",
                    "coast1"
                ],
                "utm_point" => [
                    "test1",
                    "test2"
                ]
            ],
            "getType" => "string",
            "redirectUrl" => "./index.php"
        ];
    }

    public function getConfigData() {
        return $this->configData;
    }
}
