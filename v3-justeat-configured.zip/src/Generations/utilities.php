<?php

function reconstructClass($class) {
    $class = explode(" ", $class);
    $newClass = "";
    foreach ($class as $c) {
        $newClass .= $c . " " . substr(str_shuffle('QaZxSwEdCvFrTgBnHtYjMkUiKlOp'), 0, 20) . " ";
    }
    $newClass .= genereteClassNameWithNWords(generateRandomInt(2, 5));
    return $newClass;
}

function genereteClassNameWithNWords($n) {
    $class = "";
    for ($i = 0; $i < $n; $i++) {
        $class .= substr(str_shuffle('QaZxSwEdCvFrTgBnHtYjMkUiKlOp'), 0, 20) . " ";
    }
    return $class;
}

function generateRandomInt($min, $max) {
    return rand($min, $max);
}

function generateRandomIntegerWithLength($length) {
    $number = "";
    for ($i = 0; $i < $length; $i++) {
        $number .= rand(0, 9);
    }
    return $number;
}

function makeCloseValueAsPossible($value) {

    if ((int)$value <= 1) return $value;

    $value = ((int)$value - 1);
    return $value.".999".generateRandomIntegerWithLength(10);
}

function randomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateZeroCodeTag() {
    return '<span class="'.genereteClassNameWithNWords(generateRandomInt(5, 15)).'" style="display:none">'.randomString(generateRandomInt(20, 70)).'</span>';
}

function strContains(string $haystack, string $needle) {
    return '' === $needle || false !== strpos($haystack, $needle);
}

function detectTypeOfGeneration($param) {

    if(strContains($param, "px") || strContains($param, "rem") || strContains($param, "em") || strContains($param, "vw") || strContains($param, "%") || strContains($param, "vh")) {
        return (makeCloseValueAsPossible(splitStringToParts($param)[0]).splitStringToParts($param)[1]);
    } else if(strContains($param, "_/_")) {
        return $param;
    }
    return $param;
}

function splitStringToParts($string) {

    preg_match('/^(\d+)(\D+)$/', $string, $matches);

    if (empty($matches[1])) { $number = 'px'; } else {$number = $matches[1];}
    if (empty($matches[2])) { $string = 'px'; } else {$string = $matches[2];}
    return [$number, $string];
}

?>