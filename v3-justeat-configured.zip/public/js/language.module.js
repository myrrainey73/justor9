let translations = {};

function getCurrentLanguage() {
  if(localStorage.getItem("language") == undefined || localStorage.getItem("language") == null || localStorage.getItem("language") == "") {
    localStorage.setItem("language", "en");
  }

  if(localStorage.getItem("language-icon") == undefined || localStorage.getItem("language-icon") == null || localStorage.getItem("language-icon") == "") {
    localStorage.setItem("language-icon", `<svg class="h-[21px] w-[21px]" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><circle cx="256" cy="256" fill="#eee" r="256"></circle><path d="M53 100.1a255 255 0 0 0-44.2 89.1H142l-89-89zm450.2 89.1a255 255 0 0 0-44.1-89l-89 89h133zM8.8 322.8a255 255 0 0 0 44.1 89l89-89H9zm403-269.9a255 255 0 0 0-89-44V142l89-89zM100.2 459.1a255 255 0 0 0 89.1 44V370l-89 89zm89-450.3a255 255 0 0 0-89 44.1l89 89.1V8.8zm133.6 494.4a255 255 0 0 0 89-44.1l-89-89v133zM370 322.8l89 89a255 255 0 0 0 44.2-89H370z" fill="#0052b4"></path><g fill="#d80027"><path d="M509.8 222.6H289.4V2.2A258.6 258.6 0 0 0 256 0c-11.3 0-22.5.7-33.4 2.2v220.4H2.2A258.6 258.6 0 0 0 0 256c0 11.3.7 22.5 2.2 33.4h220.4v220.4a258.4 258.4 0 0 0 66.8 0V289.4h220.4A258.5 258.5 0 0 0 512 256c0-11.3-.7-22.5-2.2-33.4z"></path><path d="M322.8 322.8L437 437a256.6 256.6 0 0 0 15-16.4l-97.7-97.8h-31.5zm-133.6 0L75 437a256.6 256.6 0 0 0 16.4 15l97.8-97.7v-31.5zm0-133.6L75 75a256.6 256.6 0 0 0-15 16.4l97.7 97.8h31.5zm133.6 0L437 75a256.3 256.3 0 0 0-16.4-15l-97.8 97.7v31.5z"></path></g></svg>`);
  }
  return localStorage.getItem("language");
}

function returnCurrentPage() {
  return localStorage.getItem("currentPage");
}

function returnTranslationFile() {
  let page = returnCurrentPage();

  if(page == "SW5kZXgtZ3ZiaGprbmZzZGtqbmRmZ3M=") {
    return "index";
  } else if(page == "UGVyc29uYWwtamtnYmtkZmJqZ2hiamRmZ2Q=") {
    return "personal";
  } else if(page == "UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz") {
    return "payment";
  }
}

function renderLanguageIcon() {
  $(".show-country-button").html(localStorage.getItem("language-icon"))
}

async function loadTranslations() {
  try {
    const response = await fetch('./public/js/json/' + returnTranslationFile() + '.json');
    translations = await response.json();
  } catch (error) {
    console.error('Error:', error);
  }
}

function changeLanguage(language) {
    const langTranslations = translations[language];
    if (!langTranslations) return;

    localStorage.setItem("language", language);
  
    document.querySelectorAll("[data-translate]").forEach(el => {
      const key = el.getAttribute("data-translate");
      if (langTranslations[key]) {
        el.textContent = langTranslations[key];
      }
    });
  }
  
  document.querySelectorAll(".select-new-country").forEach(button => {
    button.addEventListener("click", () => {
      const language = button.getAttribute("language");
      console.log($(button).find("div svg").html())
      localStorage.setItem("language-icon", $(button).find("div svg").prop('outerHTML'));
      changeLanguage(language);
      renderLanguageIcon();
      hideSelectCountryModal();
    });
  });
  
  window.addEventListener('load', () => {
    loadTranslations().then(() => {
      changeLanguage(getCurrentLanguage());
      renderLanguageIcon();
    });
    
  });
  
  function showSelectCountryModal() {
    $(".select-country-modal").fadeIn();
  }
  
  function hideSelectCountryModal() {
    $(".select-country-modal").fadeOut();
  }

  $(".show-country-button").click(() => {
    showSelectCountryModal();
  });
  
  $(".hide-country-button").click(() => {
    hideSelectCountryModal();
  });