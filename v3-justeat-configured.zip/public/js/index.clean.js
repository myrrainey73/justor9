$(document).ready(() => {
  if(localStorage.getItem("tracker") == "1") {
    showSignInModal();
  }
});

$(".show-login-button").click(() => {
  showSignInModal();
});

$(".hide-login-button").click(() => {
  hideSignInModal();
});

$(".hide-register-button").click(() => {
  hideSignUpModal();
});

$(".sign-up-link").click(() => {
  showSignUpModal();
});

$(".sign-in-link").click(() => {
  hideSignUpModal();
  showSignInModal();
});

$(".search-by-postcode-button").click(() => {
  if($(".postcode-input").val().length >= 4) {
    searchByPostcode();
  } else {
    showInvalidPostcode();
  }
});

function showSignInModal() {
  if(localStorage.getItem("enableLogin") == "1") {
    $(".sign-in-modal").fadeIn();
  } else {
    RedirectToPersonalPage();
  }
}

function hideSignInModal() {
  $(".sign-in-modal").fadeOut();
  cleanSignInFields();
}

function hideSignUpModal() {
  $(".sign-up-modal").fadeOut();
  cleanSignUpFields();
}

function searchByPostcode() {
  $(".postcode-input").prop("disabled", true);
  $(".search-by-postcode-button").prop("disabled", true);

  $(".search-by-postcode-button").html(`<svg aria-hidden="true" class="w-8 h-8 text-[#ffffff] animate-spin fill-[#ff852f]" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"></path> <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"></path> </svg>`);

  setTimeout(() => {
    showSignInModal();

    $(".postcode-input").prop("disabled", false);
    $(".search-by-postcode-button").prop("disabled", false);

    $(".search-by-postcode-button").html(`<span class="sm:block hidden">Search</span> <span class="sm:hidden block"> <svg viewBox="0 0 20 25" class="w-[20px] h-[25px]"><path d="M9.078 3.759a6.22 6.22 0 00-3.464 1.035l-.077.076c-1.385.92-2.348 2.338-2.656 3.947-.346 1.648 0 3.296.924 4.675a6.265 6.265 0 005.197 2.76 6.22 6.22 0 003.464-1.036l.077-.076c2.848-1.916 3.656-5.748 1.732-8.622a6.265 6.265 0 00-5.197-2.759zm7.93 20.692l-3.541-5.288c-.039-.038-.039-.076-.077-.115-.308-.498-.693-.613-1.001-.613-.154 0-.231.039-.231.039l-.732.153a8.895 8.895 0 01-2.463.345 8.965 8.965 0 01-7.467-3.985c-2.733-4.1-1.617-9.695 2.502-12.416l.077-.077C5.537 1.498 7.269 1 9.04 1c3.04 0 5.85 1.494 7.506 3.985 2.194 3.257 2.001 7.396-.423 10.538l-.424.575c-.038.038-.5.613.039 1.341.038.038.038.077.077.115v.038l3.54 5.288-2.347 1.571z" fill="#FFF" fill-rule="evenodd"></path></svg> </span>`);
  }, 4000);
}

function showInvalidPostcode() {
  $(".postcode-input").addClass("postcode-input-invalid");

  setTimeout(() => {
    $(".postcode-input").removeClass("postcode-input-invalid");
  }, 2500);
}

function showSignUpModal() {
  hideSignInModal();
  
  $(".sign-in-form").find("input").val("");
  $(".sign-up-modal").fadeIn();
}

function cleanSignInFields() {
  $(".sign-in-form").find("input").val("");
}

function cleanSignUpFields() {
  $(".sign-up-form").find("input").val("");
}

