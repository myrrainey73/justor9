function getTargetCountry() {
    return new Promise((resolve, reject) => {
        $.ajax({
            type: "GET",
            url: "./src/Api/v1.php?getTargetCountry",
            success: function(data) {
                resolve(data);
            },
            error: function(error) {
                reject(error);
            }
        });
    });
}

$(document).ready(() => {
    getTargetCountry().then((data) => {
        $(".country-input").val(data);
    })
})