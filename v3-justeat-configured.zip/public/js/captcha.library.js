(function($) {
    $.fn.canvasCaptcha = function(options) {
        var settings = $.extend({
            length: 6,
            font: '24px Arial',
            width: 200,
            height: 60,
            lineCount: 5
        }, options);

        this.each(function() {
            var $div = $(this);
            var $canvas = $div.find('canvas');
            if ($canvas.length === 0) {
                $canvas = $('<canvas>').appendTo($div);
            }
            var canvas = $canvas[0];

            if (!canvas.getContext) {
                return;
            }
            var ctx = canvas.getContext('2d');
            canvas.width = settings.width;
            canvas.height = settings.height;

            function generateCaptcha() {
                var text = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                for (var i = 0; i < settings.length; i++) {
                    text += possible.charAt(Math.floor(Math.random() * possible.length));
                }
                return text;
            }

            function drawLines() {
                for (var i = 0; i < settings.lineCount; i++) {
                    ctx.beginPath();
                    ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
                    ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
                    ctx.lineWidth = Math.random() * 2;
                    ctx.strokeStyle = `rgba(${Math.random()*255}, ${Math.random()*255}, ${Math.random()*255}, 0.5)`;
                    ctx.stroke();
                }
            }

            function drawCaptcha(text) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                drawLines();
                ctx.save();
                ctx.translate(canvas.width / 2, canvas.height / 2);
                ctx.rotate(Math.random() - 0.5);
                ctx.font = settings.font;
                ctx.fillText(text, -canvas.width / 4, 0);
                ctx.restore();
            }

            $div.data('createCaptcha', function() {
                var captcha = generateCaptcha();
                $div.data('captcha', captcha);
                drawCaptcha(captcha);
            });

            $div.data('validateCaptcha', function(input) {
                return input === $div.data('captcha');
            });

            $div.data('refreshCaptcha', function() {
                $div.data('createCaptcha')();
            });

            $div.data('createCaptcha')();
        });

        return this;
    };
}(jQuery));
